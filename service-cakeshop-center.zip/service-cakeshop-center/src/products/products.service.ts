import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { Product, ProductDocument } from './schemas/porducts.schema';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';

@Injectable()
export class ProductsService {
  constructor(
    @InjectModel(Product.name) private productModel: Model<ProductDocument>,
  ) {}
  async create(createProductDto: CreateProductDto): Promise<{
    data: Product | null;
    status?: number;
    message?: string;
  }> {
    try {
      const data = new this.productModel(createProductDto);
      const addData = await data.save();
      return {
        data: addData,
        status: 200,
        message: 'succeed',
      };
    } catch (error) {
      throw error;
    }
  }

  async findAll(): Promise<{
    data: Product[];
    status: number;
    message: string;
  }> {
    try {
      const products = await this.productModel.find().exec();

      return {
        data: products.length > 0 ? products : null,
        status: 200,
        message: 'succeed',
      };
    } catch (error) {
      throw error;
    }
  }

  async findOne(id: string): Promise<{
    data: Product | null;
    status: number;
    message: string;
  }> {
    try {
      const product = await this.productModel.findById(id).exec();

      if (!product) {
        return {
          data: null,
          status: 404,
          message: 'Product not found',
        };
      }
      return {
        data: product,
        status: 200,
        message: 'succeed',
      };
    } catch (error) {
      throw error;
    }
  }

  async update(
    id: string,
    updateProductDto: UpdateProductDto,
  ): Promise<{
    data: Product | null;
    status: number;
    message: string;
  }> {
    try {
      const products = await this.productModel
        .findByIdAndUpdate(id, updateProductDto, { new: true })
        .exec();
      return {
        data: products,
        status: 200,
        message: 'succeed',
      };
    } catch (error) {
      throw error;
    }
  }

  async remove(id: string) {
    try {
      const products = await this.productModel.findByIdAndDelete(id).exec();
      if (!products) {
        throw new NotFoundException('id not found');
      }
      return {
        status: 200,    
        message: 'succeed',
      };
    } catch (error) {
      throw error;
    }
  }
}
