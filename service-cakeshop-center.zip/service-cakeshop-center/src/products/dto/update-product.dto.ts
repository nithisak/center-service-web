export class UpdateProductDto {
    readonly name? : string;
    readonly description? : string;
    readonly price? : number;
}
